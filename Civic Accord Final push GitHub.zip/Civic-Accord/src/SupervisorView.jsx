// SupervisorView.jsx — Supervisor screen for Civic Accord (Supervisor Patel).
// Reviews disputes side by side (complaint · officer proof · citizen counter-proof)
// and issues a binding, reasoned ruling: Uphold (close) or Overturn (order rework).
import { useState, useMemo, useEffect } from "react";
import { STATES, CLOSED_STATES, AUTO_CLOSE_MS, PEOPLE, useCivicLedger, useNow, verifyLedger, officerWarnings, MAX_OFFICER_WARNINGS, WARNING_KINDS } from "./civicLedger";
import {
  dur, ago, stamp, StatusBadge, Icon, Card, ProofCard, Timeline, ComplaintPhotos,
  TopBar, AccessDenied, SiteFooter, LedgerBar, openPhotoViewer, StarRating, RatingCard, averageRating, CaseTimer,
} from "./shared";
import { assessPhoto, detectAiOnline, ONLINE_AI_CHECK, distanceMeters, mapsLink, formatGps } from "./imageCheck";
import { listFlagged, clearWarnings, MAX_WARNINGS } from "./photoGuard";

const MIN_RULING = 30;

const TABS = [
  { key: "disputes", label: "Disputes to rule", hint: "Contested by residents", accent: "text-rose-700", states: [STATES.CONTESTED] },
  { key: "rework", label: "Rework in progress", hint: "Overturned rulings", accent: "text-violet-700", states: [STATES.REWORK] },
  { key: "open", label: "Open cases", hint: "New + awaiting resident", accent: "text-sky-700", states: [STATES.SUBMITTED, STATES.PROPOSED] },
  { key: "closed", label: "Closed", hint: "All closures", accent: "text-emerald-700", states: CLOSED_STATES },
];

export default function SupervisorView({ session, onSignOut }) {
  if (!session || session.role !== "SUPERVISOR") {
    return <AccessDenied session={session} requiredLabel="Supervisors" onSignOut={onSignOut} />;
  }
  return <SupervisorScreen session={session} onSignOut={onSignOut} />;
}

function SupervisorScreen({ session, onSignOut }) {
  const me = PEOPLE[session.personId];
  const now = useNow();
  const { ready, events, cases, dispatch, storageWarning } = useCivicLedger(now);
  const [tab, setTab] = useState("disputes");
  const [selectedId, setSelectedId] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(t);
  }, [toast]);

  const groups = useMemo(() => {
    const g = {};
    for (const t of TABS) {
      g[t.key] = cases.filter((c) => t.states.includes(c.state)).sort((a, b) => a.updatedAt - b.updatedAt);
    }
    g.closed.reverse();
    return g;
  }, [cases]);

  const list = groups[tab];
  const selected = list.find((c) => c.id === selectedId) || list[0] || null;

  // officer accountability, computed from the ledger
  const officerStats = useMemo(() => {
    const byOfficer = {};
    const row = (id, name) => (byOfficer[id] ||= { id, name, proposals: 0, disputed: 0, overturned: 0, upheld: 0, confirmed: 0, uncontested: 0, ratingSum: 0, ratingCount: 0 });
    const officerOf = {};
    for (const e of events) {
      if (e.type === "SUBMIT") officerOf[e.caseId] = e.data.assignedTo;
      const oid = officerOf[e.caseId];
      const r = oid && row(oid, PEOPLE[oid] ? PEOPLE[oid].name : oid);
      if (!r) continue;
      if (e.type === "PROPOSE") r.proposals++;
      if (e.type === "DISPUTE") r.disputed++;
      if (e.type === "ORDER_REWORK") r.overturned++;
      if (e.type === "UPHOLD") r.upheld++;
      if (e.type === "CONFIRM") r.confirmed++;
      if ((e.type === "CONFIRM" || e.type === "RATE") && e.data && e.data.rating) { r.ratingSum += e.data.rating; r.ratingCount++; }
      if (e.type === "AUTO_CLOSE") r.uncontested++;
    }
    return Object.values(byOfficer);
  }, [events]);

  const damodarWarnings = useMemo(() => officerWarnings(events, "damodar", now), [events, now]);

  async function rule(c, action, data, warning) {
    try {
      if (warning) {
        const before = officerWarnings(events, warning.officerId, Date.now());
        if (before.suspended) throw new Error(`${warning.officerName} is already suspended.`);
        await dispatch(c.id, "WARN_OFFICER", me, warning);
        warning.suspends = before.thisWeek.length >= MAX_OFFICER_WARNINGS;
      }
      await dispatch(c.id, action, me, data);
      const base = action === "UPHOLD" ? `Ruling recorded. Case #${c.id} closed.` : `Ruling recorded. Rework ordered on #${c.id}.`;
      const extra = !warning ? "" : warning.suspends
        ? ` ${warning.officerName} exceeded ${MAX_OFFICER_WARNINGS} warnings and is now suspended for 7 days.`
        : ` Warning issued to ${warning.officerName} (${WARNING_KINDS[warning.kind].short}).`;
      setToast({ ok: true, text: base + extra });
      setSelectedId(null);
    } catch (err) {
      setToast({ ok: false, text: err.message });
    }
  }

  async function reinstate(officer, note) {
    try {
      await dispatch(`officer-${officer.id}`, "REINSTATE_OFFICER", me, { officerId: officer.id, officerName: officer.name, note });
      setToast({ ok: true, text: `${officer.name} has been reinstated. Their weekly warning count starts again from 0.` });
    } catch (err) {
      setToast({ ok: false, text: err.message });
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <TopBar subtitle="Supervisor console · Reasoned review of disputed closures" bg="bg-[#1e3a5f]" session={session} onSignOut={onSignOut} avatarText="text-[#1e3a5f]"
        stats={[
          { label: "Disputes waiting", value: groups.disputes.length },
          { label: "Rulings made", value: events.filter((e) => e.actorId === me.id && (e.type === "UPHOLD" || e.type === "ORDER_REWORK")).length },
          { label: "Cases closed", value: groups.closed.length },
        ]}
      />

      {storageWarning && (
        <p role="status" className="bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">{storageWarning}</p>
      )}

      <main className="mx-auto max-w-7xl px-4 py-6">
        {!ready ? (
          <p className="py-20 text-center text-slate-500">Loading…</p>
        ) : (
          <>
            <AiFlagAlert events={events} now={now} onOpen={(id) => { const k = Object.keys(groups).find((t) => groups[t].some((x) => x.id === id)); if (k) { setTab(k); setSelectedId(id); } }} />

            <div className="grid grid-cols-2 gap-3 md:grid-cols-4" role="tablist">
              {TABS.map((t) => {
                const active = tab === t.key;
                return (
                  <button
                    key={t.key}
                    role="tab"
                    aria-selected={active}
                    type="button"
                    onClick={() => { setTab(t.key); setSelectedId(null); }}
                    className={`rounded-2xl p-4 text-left ring-1 transition ${active ? "bg-white shadow-md ring-2 ring-[#1e3a5f]" : "bg-white/70 ring-slate-200 hover:bg-white"}`}
                  >
                    <p className={`text-3xl font-bold tabular-nums ${t.accent}`}>{groups[t.key].length}</p>
                    <p className="mt-1 text-sm font-semibold text-slate-800">{t.label}</p>
                    <p className="text-xs text-slate-500">{t.hint}</p>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-[320px_1fr]">
              <aside className="space-y-2" aria-label="Case list">
                {list.length === 0 && (
                  <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-500 ring-1 ring-slate-200">
                    {tab === "disputes" ? "No disputes waiting. All clear." : "Nothing here right now."}
                  </p>
                )}
                {list.map((c) => {
                  const active = selected && selected.id === c.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedId(c.id)}
                      className={`w-full rounded-2xl p-4 text-left ring-1 transition ${active ? "bg-sky-50 ring-2 ring-[#1e3a5f]" : "bg-white ring-slate-200 hover:ring-sky-400"}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-mono text-xs text-slate-500">#{c.id}</span>
                        <StatusBadge state={c.state} />
                      </div>
                      <p className="mt-1 font-semibold">{c.title}</p>
                      <p className="text-sm text-slate-600">{c.location}</p>
                      <p className="mt-2 text-xs text-slate-500">
                        {c.state === STATES.CONTESTED ? `Disputed by ${c.citizenName} on ${stamp(c.disputedAt)}` : `Updated on ${stamp(c.updatedAt)}`}
                      </p>
                      <div className="mt-2"><CaseTimer c={c} /></div>
                      {c.aiFlags && c.aiFlags.length > 0 && (
                        <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-violet-100 px-2 py-0.5 text-[11px] font-bold text-violet-800">
                          🤖 AI photo flagged ×{c.aiFlags.length}
                        </span>
                      )}
                    </button>
                  );
                })}

                <OfficerTable rows={officerStats} events={events} now={now} />
                <WarningsColumn w={damodarWarnings} officer={PEOPLE.damodar} now={now} onOpen={(id) => { const c = cases.find((x) => x.id === id); if (c) { setTab(Object.keys(groups).find((k) => k !== "all" && groups[k].some((x) => x.id === id)) || tab); setSelectedId(id); } }} onReinstate={reinstate} />
                <FlaggedAccounts />
              </aside>

              <div>
                {selected ? (
                  <CaseDetail key={selected.id + selected.events.length} c={selected} now={now} onRule={rule} officerWarn={damodarWarnings} />
                ) : (
                  <p className="rounded-2xl bg-white p-10 text-center text-slate-500 ring-1 ring-slate-200">Select a case.</p>
                )}
              </div>
            </div>

            <LedgerBar events={events} verify={verifyLedger} />
          </>
        )}
      </main>

      <SiteFooter />

      {toast && (
        <div role="status" className={`fixed bottom-4 left-1/2 z-30 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-xl px-4 py-3 text-sm font-medium text-white shadow-lg ${toast.ok ? "bg-emerald-700" : "bg-rose-700"}`}>
          {toast.text}
        </div>
      )}
    </div>
  );
}

function AiFlagAlert({ events, now, onOpen }) {
  const recent = events
    .filter((e) => e.type === "AI_FLAG" && now - e.at < 7 * 24 * 3600 * 1000)
    .sort((a, b) => b.at - a.at);
  if (!recent.length) return null;
  return (
    <section role="status" className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-violet-50 px-4 py-3 ring-1 ring-violet-300">
      <p className="text-sm text-violet-950">
        <b>🤖 AI detector:</b> {recent.length === 1 ? "1 officer photo was" : `${recent.length} officer photos were`} rejected as AI-generated this week.
        Latest: case #{recent[0].caseId}, {stamp(recent[0].at)}.
      </p>
      <button type="button" onClick={() => onOpen(recent[0].caseId)} className="rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-violet-800 ring-1 ring-violet-300 hover:bg-violet-100">
        Open case #{recent[0].caseId}
      </button>
    </section>
  );
}

function OfficerTable({ rows, events, now }) {
  const warnRow = (id) => {
    const w = officerWarnings(events, id, now);
    const n = w.thisWeek.length;
    return (
      <div className={`mt-2 flex items-center justify-between gap-1 rounded-lg px-2 py-1.5 ring-1 ${w.suspended ? "bg-rose-50 ring-rose-200" : "bg-slate-50 ring-slate-200"}`}>
        <span className="text-[11px] font-medium text-slate-700">Warnings this week</span>
        <span className={`text-[11px] font-bold ${w.suspended ? "text-rose-700" : n ? "text-amber-800" : "text-slate-500"}`}>
          {w.suspended ? "Suspended" : `${n}/${MAX_OFFICER_WARNINGS}`}
        </span>
      </div>
    );
  };
  return (
    <Card className="!p-4">
      <h3 className="text-sm font-semibold">Officer accountability</h3>
      <p className="text-xs text-slate-500">Computed live from the audit ledger.</p>
      <div className="mt-3 space-y-3">
        {rows.map((r) => {
          const disputeRate = r.proposals ? Math.round((r.disputed / r.proposals) * 100) : 0;
          return (
            <div key={r.id}>
              <p className="text-sm font-medium">{r.name}</p>
              <dl className="mt-1 grid grid-cols-3 gap-1 text-center text-xs">
                <Stat label="Proposals" value={r.proposals} />
                <Stat label="Disputed" value={`${r.disputed} (${disputeRate}%)`} />
                <Stat label="Overturned" value={r.overturned} />
                <Stat label="Confirmed" value={r.confirmed} />
                <Stat label="Uncontested" value={r.uncontested} />
                <Stat label="Upheld" value={r.upheld} />
              </dl>
              {warnRow(r.id)}
              <div className="mt-2 flex flex-wrap items-center justify-between gap-1 rounded-lg bg-amber-50 px-2 py-1.5 ring-1 ring-amber-200">
                <span className="text-[11px] font-medium text-amber-900">Resident rating</span>
                {r.ratingCount
                  ? <span className="flex items-center gap-1"><StarRating value={Math.round((r.ratingSum / r.ratingCount) * 10) / 10} size="h-3.5 w-3.5" /><span className="text-[10px] text-amber-900/70">({r.ratingCount})</span></span>
                  : <span className="text-[11px] text-amber-900/60">No ratings yet</span>}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function WarningsColumn({ w, officer, now, onOpen, onReinstate }) {
  const [confirming, setConfirming] = useState(false);
  const [note, setNote] = useState("");
  const n = w.thisWeek.length;
  const active = (x) => now - x.at < 7 * 24 * 3600 * 1000 && x.at > (w.reinstatedAt || 0);
  return (
    <Card className="!p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold">Warnings issued</h3>
          <p className="text-xs text-slate-500">{officer.name} · max {MAX_OFFICER_WARNINGS} per week, then suspension.</p>
        </div>
        <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-bold ${w.suspended ? "bg-rose-600 text-white" : n ? "bg-amber-200 text-amber-950" : "bg-slate-100 text-slate-600"}`}>
          {w.suspended ? "Suspended" : `${n}/${MAX_OFFICER_WARNINGS}`}
        </span>
      </div>

      <div className="mt-2 flex gap-1" aria-hidden="true">
        {Array.from({ length: MAX_OFFICER_WARNINGS }, (_, i) => (
          <span key={i} className={`h-1.5 flex-1 rounded-full ${i < n ? (w.suspended ? "bg-rose-500" : "bg-amber-500") : "bg-slate-200"}`} />
        ))}
      </div>

      {w.suspended && (
        <div className="mt-3 rounded-lg bg-rose-50 p-2.5 ring-1 ring-rose-200">
          <p className="text-xs font-semibold text-rose-900">Suspended until {stamp(w.suspended.until)}</p>
          <p className="mt-0.5 text-[11px] text-rose-800">Can't submit resolutions. Lifts automatically after 7 days.</p>
          {!confirming ? (
            <button type="button" onClick={() => setConfirming(true)} className="mt-2 rounded-lg bg-white px-2.5 py-1 text-xs font-semibold text-rose-800 ring-1 ring-rose-300 hover:bg-rose-100">
              Reinstate early
            </button>
          ) : (
            <div className="mt-2">
              <label htmlFor="reinstate-note" className="block text-[11px] font-medium text-rose-900">Reason for reinstating</label>
              <input id="reinstate-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Met with officer, retraining done"
                className="mt-1 w-full rounded-md border border-rose-300 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-rose-300" />
              <div className="mt-1.5 flex gap-1.5">
                <button type="button" disabled={note.trim().length < 10} onClick={() => { onReinstate(officer, note.trim()); setConfirming(false); setNote(""); }}
                  className="rounded-md bg-rose-700 px-2.5 py-1 text-xs font-semibold text-white disabled:bg-slate-300">Confirm reinstate</button>
                <button type="button" onClick={() => setConfirming(false)} className="rounded-md px-2 py-1 text-xs text-slate-600 hover:bg-white">Cancel</button>
              </div>
            </div>
          )}
        </div>
      )}

      {w.all.length === 0 ? (
        <p className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-500 ring-1 ring-slate-200">No warnings issued yet.</p>
      ) : (
        <ul className="mt-3 max-h-80 space-y-2 overflow-y-auto pr-1">
          {w.all.map((x, i) => {
            const live = active(x);
            const tampered = x.kind === "TAMPERED";
            return (
              <li key={i}>
                <button type="button" onClick={() => onOpen(x.caseId)} className={`w-full rounded-lg px-2.5 py-2 text-left ring-1 transition hover:ring-[#1e3a5f] ${live ? "bg-white ring-slate-200" : "bg-slate-50 opacity-70 ring-slate-200"}`}>
                  <div className="flex flex-wrap items-center gap-1">
                    <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${tampered ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-900"}`}>
                      {WARNING_KINDS[x.kind].short}
                    </span>
                    {x.auto && <span className="rounded-full bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold text-violet-800">AI detector</span>}
                    {x.suspends && <span className="rounded-full bg-rose-600 px-1.5 py-0.5 text-[10px] font-bold text-white">Suspended</span>}
                    {!live && <span className="rounded-full bg-slate-200 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600">Expired</span>}
                  </div>
                  <p className="mt-1 text-xs text-slate-800">“{x.reason}”</p>
                  <p className="mt-0.5 text-[10px] text-slate-500">Case #{x.caseId} · {stamp(x.at)}</p>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-lg bg-slate-50 px-1 py-1.5 ring-1 ring-slate-200">
      <dd className="font-semibold tabular-nums text-slate-900">{value}</dd>
      <dt className="text-[10px] text-slate-500">{label}</dt>
    </div>
  );
}

/* ---------------- case detail + ruling ---------------- */
function CaseDetail({ c, now, onRule, officerWarn }) {
  const contested = c.state === STATES.CONTESTED;
  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="font-mono text-xs text-slate-500">CASE #{c.id} · {c.category}</p>
            <h2 className="mt-1 text-xl font-semibold">{c.title}</h2>
            <p className="mt-0.5 text-sm text-slate-600">{c.location} · Resident {c.citizenName} · Officer Damodar</p>
            <div className="mt-2"><CaseTimer c={c} /></div>
          </div>
          <StatusBadge state={c.state} />
        </div>
      </Card>

      {c.aiFlags && c.aiFlags.length > 0 && (
        <section role="alert" className="rounded-2xl bg-violet-50 p-4 ring-1 ring-violet-300">
          <p className="text-sm font-semibold text-violet-950">🤖 The AI detector rejected {c.aiFlags.length === 1 ? "an officer photo" : `${c.aiFlags.length} officer photos`} on this case</p>
          <p className="mt-0.5 text-xs text-violet-900/80">The photo was not attached. Each rejection is recorded as a tampered-image warning for the officer.</p>
          <ul className="mt-2 space-y-1">
            {c.aiFlags.map((f, i) => (
              <li key={i} className="text-xs text-violet-950">
                {stamp(f.at)} · {f.officerName} · {f.reason}{f.suspends ? " · officer suspended" : ""}
              </li>
            ))}
          </ul>
        </section>
      )}

      {contested ? (
        <>
          <section>
            <h3 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Evidence dossier</h3>
            <div className="grid gap-4 xl:grid-cols-3">
              <Card>
                <h4 className="text-sm font-semibold">1 · Original complaint</h4>
                <p className="text-xs text-slate-500">{c.citizenName} · {stamp(c.submittedAt)}</p>
                <div className="mt-3 max-w-[12rem]"><ComplaintPhotos c={c} /></div>
                <p className="mt-3 text-sm leading-relaxed text-slate-700">{c.description}</p>
              </Card>
              <ProofCard title="2 · Officer's proof" proof={c.proposal} at={c.proposedAt} />
              <ProofCard title="3 · Resident's counter-proof" proof={c.dispute} at={c.disputedAt} tone="citizen" />
            </div>
          </section>
          <LocationCheck c={c} />
          <PhotoCheck key={c.id} c={c} />
          <RulingForm c={c} onRule={onRule} officerWarn={officerWarn} />
        </>
      ) : (
        <ReadOnlyPanel c={c} now={now} />
      )}

      <Timeline c={c} />
    </div>
  );
}

function RulingForm({ c, onRule, officerWarn }) {
  const [ruling, setRuling] = useState("");
  const [bulkTruck, setBulkTruck] = useState(false);
  const [busy, setBusy] = useState(null);
  const [warn, setWarn] = useState(false);
  const [warnReason, setWarnReason] = useState("");
  const [warnKind, setWarnKind] = useState(null);
  const hadRework = (c.reworkCount || 0) > 0;
  const weekCount = officerWarn ? officerWarn.thisWeek.length : 0;
  const suspended = officerWarn && officerWarn.suspended;
  const willSuspend = weekCount >= MAX_OFFICER_WARNINGS; // a warning beyond 3 suspends
  const warnOk = !warn || (warnKind && warnReason.trim().length >= 15);
  const ok = ruling.trim().length >= MIN_RULING && warnOk;

  async function submit(action) {
    if (!ok || busy) return;
    setBusy(action);
    await onRule(
      c, action,
      { ruling: ruling.trim(), outcome: action === "UPHOLD" ? "UPHELD" : "OVERTURNED", bulkTruckDispatched: bulkTruck },
      warn && !suspended ? { officerId: "damodar", officerName: "Officer Damodar", kind: warnKind, reason: warnReason.trim() } : null
    );
    setBusy(null);
  }

  return (
    <Card className="ring-2 ring-[#1e3a5f]/30">
      <h3 className="text-lg font-semibold">Reasoned ruling</h3>
      <p className="mt-1 text-sm text-slate-600">
        Your ruling is binding and permanently recorded in the audit ledger. Explain what the evidence shows.
      </p>
      <label htmlFor={`ruling-${c.id}`} className="mt-4 block text-sm font-medium">Reasoning</label>
      <textarea
        id={`ruling-${c.id}`}
        rows={4}
        value={ruling}
        onChange={(e) => setRuling(e.target.value)}
        placeholder="e.g. The officer's photo shows the bin emptied, but the resident's photo shows bulk cardboard still on the lawn. The complaint is only partly resolved."
        className="mt-1.5 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm focus:border-[#1e3a5f] focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30"
      />
      <p className={`mt-1 text-xs ${ok ? "text-emerald-700" : "text-slate-500"}`}>{ruling.trim().length}/{MIN_RULING} characters minimum</p>

      <label className="mt-3 flex cursor-pointer items-center gap-2 text-sm">
        <input type="checkbox" checked={bulkTruck} onChange={(e) => setBulkTruck(e.target.checked)} className="h-4 w-4 rounded border-slate-300 accent-[#1e3a5f]" />
        Dispatch bulk pickup truck
      </label>

      <div className={`mt-4 rounded-xl p-4 ring-1 ${suspended || (warn && willSuspend) ? "bg-rose-50 ring-rose-200" : "bg-amber-50 ring-amber-200"}`}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold text-slate-900">Warn the officer?</p>
          <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${suspended ? "bg-rose-600 text-white" : willSuspend ? "bg-rose-200 text-rose-900" : "bg-amber-200 text-amber-950"}`}>
            Officer Damodar: {suspended ? "suspended" : `${weekCount}/${MAX_OFFICER_WARNINGS} warnings this week`}
          </span>
        </div>
        <p className="mt-1 text-xs text-slate-600">
          For incomplete work or a tampered / fake proof photo. Max {MAX_OFFICER_WARNINGS} warnings per week; one more after that suspends the officer for 7 days.
          {hadRework && ` This case was already sent back for rework ${c.reworkCount === 1 ? "once" : `${c.reworkCount} times`}.`}
        </p>
        {suspended ? (
          <p className="mt-2 text-sm text-rose-800">
            Officer Damodar is suspended until {stamp(suspended.until)} and can't submit resolutions. No further warnings can be issued.
          </p>
        ) : (
          <>
            <label className="mt-3 flex cursor-pointer items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={warn} onChange={(e) => setWarn(e.target.checked)} className="h-4 w-4 rounded border-slate-300 accent-amber-600" />
              {willSuspend ? "Issue a 4th warning and suspend Officer Damodar" : "Issue a formal warning to Officer Damodar"}
            </label>
            {warn && (
              <>
                <p className="mt-3 text-xs font-medium text-slate-700">Warning type</p>
                <div className="mt-1 flex flex-wrap gap-2" role="radiogroup" aria-label="Warning type">
                  {["INCOMPLETE", "TAMPERED"].map((k) => (
                    <button
                      key={k} type="button" role="radio" aria-checked={warnKind === k} onClick={() => setWarnKind(k)}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold ring-1 transition ${warnKind === k ? (k === "TAMPERED" ? "bg-rose-600 text-white ring-rose-600" : "bg-amber-600 text-white ring-amber-600") : "bg-white text-slate-700 ring-slate-300 hover:ring-amber-400"}`}
                    >
                      {k === "TAMPERED" ? "🖼 " : "🛠 "}{WARNING_KINDS[k].label}
                    </button>
                  ))}
                </div>
                {warnKind === "TAMPERED" && (
                  <p className="mt-1 text-xs text-slate-600">Tip: run the AI photo check above and mention what it found.</p>
                )}
                <label htmlFor={`warn-${c.id}`} className="mt-3 block text-xs font-medium text-slate-700">Reason for the warning (the officer will see this)</label>
                <textarea
                  id={`warn-${c.id}`} rows={2} value={warnReason} onChange={(e) => setWarnReason(e.target.value)}
                  placeholder={warnKind === "TAMPERED" ? "e.g. Proof photo is an edited copy of the complaint photo; the AI check flagged it." : "e.g. Second proof again ignored the blocked drain named in the rework order."}
                  className="mt-1 w-full rounded-lg border border-amber-300 bg-white px-3 py-2 text-sm focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-400/30"
                />
                <p className={`mt-1 text-xs ${warnReason.trim().length >= 15 ? "text-emerald-700" : "text-slate-500"}`}>
                  {warnReason.trim().length}/15 characters minimum{!warnKind && " · choose a warning type"}
                </p>
                {willSuspend ? (
                  <p className="mt-1 text-xs font-semibold text-rose-700">Officer Damodar already has {MAX_OFFICER_WARNINGS} warnings this week. This warning exceeds the limit and suspends him for 7 days.</p>
                ) : weekCount + 1 === MAX_OFFICER_WARNINGS && (
                  <p className="mt-1 text-xs font-semibold text-amber-800">This will be warning {MAX_OFFICER_WARNINGS} of {MAX_OFFICER_WARNINGS}. One more this week will suspend the officer.</p>
                )}
              </>
            )}
          </>
        )}
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <button
          type="button"
          disabled={!ok || !!busy}
          onClick={() => submit("ORDER_REWORK")}
          className="rounded-xl bg-violet-700 px-4 py-3 text-sm font-semibold text-white hover:bg-violet-800 disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {busy === "ORDER_REWORK" ? "Recording…" : "Overturn: order rework"}
        </button>
        <button
          type="button"
          disabled={!ok || !!busy}
          onClick={() => submit("UPHOLD")}
          className="rounded-xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white hover:bg-black disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {busy === "UPHOLD" ? "Recording…" : "Uphold officer: close case"}
        </button>
      </div>
      <p className="mt-3 text-xs text-slate-500">
        Overturn sends the case back to the officer for fresh proof. Uphold closes it as <span className="font-mono">REVIEWER_CLOSED</span>.
      </p>
    </Card>
  );
}

function ReadOnlyPanel({ c, now }) {
  const box = {
    [STATES.SUBMITTED]: ["bg-sky-50 ring-sky-200 text-sky-950", "Waiting for the officer's resolution proposal."],
    [STATES.PROPOSED]: ["bg-amber-50 ring-amber-200 text-amber-950", `Waiting for ${c.citizenName} to verify. Auto-closes in ${dur(c.proposedAt + AUTO_CLOSE_MS - now)}.`],
    [STATES.REWORK]: ["bg-violet-50 ring-violet-200 text-violet-950", c.ruling ? `Your ruling: ${c.ruling.ruling}` : "Rework ordered."],
  }[c.state] || ["bg-emerald-50 ring-emerald-200 text-emerald-950",
    c.state === STATES.REVIEWER_CLOSED && c.ruling ? `Closed by your ruling: ${c.ruling.ruling}`
      : c.state === STATES.CONFIRMED ? `${c.citizenName} confirmed the work.`
      : "Closed automatically: no resident response within 72 hours."];
  return (
    <>
      <section className={`rounded-2xl p-5 ring-1 ${box[0]}`}>
        <p className="text-sm">{box[1]}</p>
        {c.ruling && c.ruling.bulkTruckDispatched && <p className="mt-2 text-xs font-semibold">Bulk pickup truck dispatched.</p>}
        <p className="mt-2 text-xs opacity-70">Read-only. Supervisors only rule on contested cases.</p>
      </section>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h4 className="text-sm font-semibold">Original complaint</h4>
          <div className="mt-3 max-w-[12rem]"><ComplaintPhotos c={c} /></div>
          <p className="mt-3 text-sm text-slate-700">{c.description}</p>
        </Card>
        <ProofCard title="Officer's proof" proof={c.proposal} at={c.proposedAt} />
      </div>
      {c.rating && <RatingCard rating={c.rating} who="Resident's rating" />}
    </>
  );
}

/* ---------------- location check (from the photos' GPS) ---------------- */
function firstGps(photos) {
  const p = (photos || []).find((x) => x && x.signals && x.signals.gps);
  return p ? p.signals.gps : null;
}
function LocationCheck({ c }) {
  const home = firstGps(c.photos);
  const rows = [
    ...((c.proposal && c.proposal.photos) || []).map((p, i) => ({ who: `Officer proof ${i + 1}`, gps: p.signals && p.signals.gps })),
    ...((c.dispute && c.dispute.photos) || []).map((p, i) => ({ who: `Resident counter-proof ${i + 1}`, gps: p.signals && p.signals.gps })),
  ];
  if (!home && !rows.some((r) => r.gps)) return null;
  return (
    <Card>
      <h4 className="text-sm font-semibold">📍 Location check</h4>
      <p className="text-xs text-slate-500">From the GPS saved in each photo. Shows how far each photo was taken from the original complaint photo.</p>
      {home ? (
        <p className="mt-2 text-xs text-slate-700">Complaint photo: <a className="font-medium text-sky-700 hover:underline" href={mapsLink(home)} target="_blank" rel="noopener noreferrer">{formatGps(home)}</a></p>
      ) : (
        <p className="mt-2 text-xs text-slate-500">The complaint photo has no GPS location, so distances can't be compared.</p>
      )}
      <ul className="mt-2 space-y-1.5">
        {rows.map((r, i) => {
          const d = home && r.gps ? distanceMeters(home, r.gps) : null;
          const tone = d == null ? "bg-slate-100 text-slate-600" : d <= 100 ? "bg-emerald-100 text-emerald-800" : d <= 500 ? "bg-amber-100 text-amber-900" : "bg-rose-100 text-rose-800";
          return (
            <li key={i} className="flex flex-wrap items-center gap-2 text-xs">
              <span className="font-medium text-slate-700">{r.who}:</span>
              {r.gps ? <a className="text-sky-700 hover:underline" href={mapsLink(r.gps)} target="_blank" rel="noopener noreferrer">{formatGps(r.gps)}</a> : <span className="text-slate-500">no GPS location</span>}
              {d != null && (
                <span className={`rounded-full px-2 py-0.5 font-semibold ${tone}`}>
                  {d < 1000 ? `${d} m` : `${(d / 1000).toFixed(1)} km`} from complaint{d > 500 ? " · different place?" : d <= 100 ? " · same spot" : ""}
                </span>
              )}
            </li>
          );
        })}
      </ul>
    </Card>
  );
}

/* ---------------- AI photo check (advisory) ---------------- */
const LEVEL_STYLE = {
  high:    { badge: "bg-rose-100 text-rose-800 ring-rose-200", dot: "bg-rose-500" },
  medium:  { badge: "bg-amber-100 text-amber-900 ring-amber-200", dot: "bg-amber-500" },
  low:     { badge: "bg-emerald-100 text-emerald-800 ring-emerald-200", dot: "bg-emerald-500" },
  unknown: { badge: "bg-slate-100 text-slate-700 ring-slate-200", dot: "bg-slate-400" },
  demo:    { badge: "bg-slate-100 text-slate-700 ring-slate-200", dot: "bg-slate-400" },
};

function PhotoCheck({ c }) {
  const photos = [
    ...((c.photos || []).map((p, i) => ({ p, label: `Complaint photo ${i + 1}`, who: "Resident" }))),
    ...(((c.proposal && c.proposal.photos) || []).map((p, i) => ({ p, label: `Officer proof ${i + 1}`, who: "Officer" }))),
    ...(((c.dispute && c.dispute.photos) || []).map((p, i) => ({ p, label: `Counter-proof ${i + 1}`, who: "Resident" }))),
  ];
  const [results, setResults] = useState(null);
  const [online, setOnline] = useState({}); // index -> { loading, score, error }

  function runLocal() {
    setResults(photos.map(({ p }) => assessPhoto(p)));
  }

  async function runOnline(i) {
    setOnline((o) => ({ ...o, [i]: { loading: true } }));
    try {
      const r = await detectAiOnline(photos[i].p.src);
      setOnline((o) => ({ ...o, [i]: { score: r.aiGenerated } }));
    } catch (err) {
      setOnline((o) => ({ ...o, [i]: { error: err.message } }));
    }
  }

  return (
    <Card className="ring-2 ring-violet-200">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="max-w-xl">
          <h3 className="flex items-center gap-2 text-lg font-semibold">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-violet-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M12 3l1.8 4.6L18 9.4l-4.2 1.8L12 16l-1.8-4.8L6 9.4l4.2-1.8z" /><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z" /></svg>
            AI photo check
          </h3>
          <p className="mt-1 text-sm text-slate-600">
            Checks each photo for signs it's AI-generated or edited instead of taken on site. It's advice for your ruling. Detectors can be wrong, so never rule on this alone.
          </p>
        </div>
        <button
          type="button" onClick={runLocal} disabled={!photos.length}
          className="rounded-xl bg-violet-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-violet-800 disabled:bg-slate-300"
        >
          {results ? "Check again" : `Check ${photos.length} photo${photos.length === 1 ? "" : "s"}`}
        </button>
      </div>

      {results && (
        <ul className="mt-4 space-y-3">
          {photos.map(({ p, label, who }, i) => {
            const r = results[i];
            const st = LEVEL_STYLE[r.level];
            const o = online[i];
            return (
              <li key={i} className="flex gap-3 rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200">
                <button type="button" onClick={() => openPhotoViewer(photos.map((x) => x.p), i, "Photos in this case")} aria-label={`View ${label} full screen`} className="shrink-0 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-500">
                  <img src={p.src} alt={label} className="h-16 w-20 rounded-lg object-cover ring-1 ring-slate-200 hover:brightness-90" />
                </button>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold">{label}</span>
                    <span className="text-xs text-slate-500">from {who}</span>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ring-1 ${st.badge}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${st.dot}`} />{r.label}
                    </span>
                  </div>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4 text-xs text-slate-600">
                    {r.reasons.map((t, k) => <li key={k}>{t}</li>)}
                  </ul>
                  {r.level !== "demo" && (
                    <div className="mt-2 text-xs">
                      {!o && (
                        <button type="button" onClick={() => runOnline(i)} className="font-semibold text-violet-700 hover:underline">
                          {ONLINE_AI_CHECK ? "Run AI detection model" : "AI detection model (needs online setup)"}
                        </button>
                      )}
                      {o && o.loading && <span className="text-slate-500">Asking the AI detection model…</span>}
                      {o && typeof o.score === "number" && (
                        <span className={`inline-flex items-center gap-2 font-semibold ${o.score >= 0.7 ? "text-rose-700" : o.score >= 0.3 ? "text-amber-800" : "text-emerald-700"}`}>
                          AI detection model: {Math.round(o.score * 100)}% likely AI-generated
                          <span className="inline-block h-1.5 w-24 overflow-hidden rounded-full bg-slate-200"><span className="block h-full bg-current" style={{ width: `${Math.round(o.score * 100)}%` }} /></span>
                        </span>
                      )}
                      {o && o.error && <span className="text-slate-500">{o.error}</span>}
                    </div>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

/* ---------------- accounts warned for AI-generated photos ---------------- */
function FlaggedAccounts() {
  const [rows, setRows] = useState(null);
  const [confirm, setConfirm] = useState(null);

  async function load() {
    try { setRows(await listFlagged()); } catch { setRows([]); }
  }
  useEffect(() => {
    load();
    const t = setInterval(load, 15000); // pick up new warnings from other screens and devices
    window.addEventListener("photoguard:change", load);
    return () => { clearInterval(t); window.removeEventListener("photoguard:change", load); };
  }, []);

  async function clear(userId) {
    if (confirm !== userId) { setConfirm(userId); return; }
    setConfirm(null);
    await clearWarnings(userId);
    load();
  }

  return (
    <Card className="!p-4">
      <div className="flex items-baseline justify-between gap-2">
        <h3 className="text-sm font-semibold">Resident accounts flagged</h3>
        <button type="button" onClick={load} className="text-xs font-semibold text-sky-700 hover:underline">Refresh</button>
      </div>
      <p className="text-xs text-slate-500">Residents warned by the AI detector for AI-generated complaint photos. {MAX_WARNINGS} warnings suspend the account.</p>
      {rows === null && <p className="mt-3 text-xs text-slate-500">Loading…</p>}
      {rows && rows.length === 0 && <p className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-500 ring-1 ring-slate-200">No warnings so far.</p>}
      {rows && rows.length > 0 && (
        <ul className="mt-3 space-y-2">
          {rows.map((r) => {
            const blocked = r.count >= MAX_WARNINGS;
            return (
              <li key={r.userId} className={`rounded-lg px-3 py-2 ring-1 ${blocked ? "bg-rose-50 ring-rose-200" : "bg-amber-50 ring-amber-200"}`}>
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{r.userName}</p>
                    <p className="text-[11px] text-slate-500">{r.role === "OFFICER" ? "Officer" : "Resident"} · last {stamp(r.last)}</p>
                  </div>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold ${blocked ? "bg-rose-600 text-white" : "bg-amber-200 text-amber-950"}`}>
                    {blocked ? "Suspended" : `${r.count}/${MAX_WARNINGS} warnings`}
                  </span>
                </div>
                <button
                  type="button" onClick={() => clear(r.userId)}
                  className={`mt-1.5 text-xs font-semibold ${confirm === r.userId ? "text-rose-700" : "text-sky-700"} hover:underline`}
                >
                  {confirm === r.userId ? "Click again to confirm" : blocked ? "Lift suspension" : "Clear warnings"}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}
