# Civic Accord: team setup

## Run it on your laptop
1. Install Node.js 18 or newer (nodejs.org).
2. Extract this folder, open a terminal inside `Civic-Accord`, then run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the address it prints (usually http://localhost:5173).

Demo logins:
- Resident: mobile 9876543210, PIN 1111
- Officer: PIN 2222
- Supervisor: PIN 3333

## Push it to your own GitHub
1. On github.com, create a new **empty** repository. Don't add a README, .gitignore or license.
2. In a terminal inside `Civic-Accord`, run:
   ```bash
   git init
   git add .
   git commit -m "Civic Accord"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```
3. When asked for a password, use a GitHub **Personal access token** (GitHub → Settings → Developer settings → Tokens).

To work on the team's shared repo instead of making a copy, ask the owner to add you as a collaborator. Then run:
`git clone https://github.com/vanshmittal-09/-Civic-Accord.git`

## Good to know
- `node_modules/`, `dist/` and `.env` are ignored on purpose. Never commit `.env`, because it holds your Supabase keys.
- Supabase (shared online database) is optional. See README → Supabase. Without it, data stays in each browser.
- The AI detector model (`public/models`) and its engine (`public/ort`) are part of the project. Keep them.
